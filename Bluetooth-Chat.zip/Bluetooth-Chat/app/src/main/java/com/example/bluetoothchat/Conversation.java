package com.example.bluetoothchat;

import android.arch.persistence.room.Entity;
import android.support.annotation.NonNull;

import java.util.ArrayList;


@Entity(tableName = "Conversation_Table")
public class Conversation {

    @NonNull

    private ArrayList<String> converation;
    private String ID;



    public Conversation(@NonNull ArrayList<String> converation, String ID){
        this.converation = converation;
        this.ID = ID;
    }

    public ArrayList<String> getWord(){
        return converation;
    }

    public String getID(){
        return ID;
    }
}
